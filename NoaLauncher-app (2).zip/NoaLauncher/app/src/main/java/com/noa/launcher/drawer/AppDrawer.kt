package com.noa.launcher.drawer

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noa.launcher.settings.UiPrefs
import com.noa.launcher.ui.CyberButton
import com.noa.launcher.ui.CyberPanel
import com.noa.launcher.ui.Cy
import com.noa.launcher.ui.MonoText
import com.noa.launcher.ui.PinPad
import com.noa.launcher.ui.SmallCut

/**
 * Drawer compacto (4–6 colunas, ícones pequenos). A tela inicial não é desenhada enquanto ele está aberto.
 * Toque longo num app: menu (fixar nos atalhos / ocultar). Cadeado: abre o cofre de apps ocultos (senha).
 */
@Composable
fun AppDrawer(
    apps: List<AppInfo>,
    query: String,
    ui: UiPrefs,
    accent: Color,
    pinnedKeys: List<String>,
    vault: Boolean,
    pinLength: Int,
    onQuery: (String) -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onTogglePin: (AppInfo) -> Unit,
    onToggleHidden: (AppInfo) -> Unit,
    checkPin: (String) -> Boolean,
    onVault: (Boolean) -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    var askPin by remember { mutableStateOf(false) }
    var menuApp by remember { mutableStateOf<AppInfo?>(null) }

    val cols = ui.columns
    val iconDp = when (cols) { 4 -> 46; 5 -> 40; else -> 34 }
    val labelSize = if (cols >= 6) 8 else 9

    Box(
        modifier
            .fillMaxSize()
            .background(Color(0xFF020409).copy(alpha = ui.glass(0.8f)))
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp)
        ) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .weight(1f)
                        .clip(SmallCut)
                        .border(1.dp, accent.copy(alpha = ui.line(0.7f)), SmallCut)
                        .padding(horizontal = 12.dp, vertical = 11.dp)
                ) {
                    if (query.isEmpty()) MonoText(if (vault) "> BUSCAR NO COFRE_" else "> BUSCAR APP_", color = Cy.Dim, size = 13)
                    BasicTextField(
                        value = query,
                        onValueChange = onQuery,
                        singleLine = true,
                        textStyle = TextStyle(color = Cy.Text, fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                        cursorBrush = SolidColor(accent),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Spacer(Modifier.width(8.dp))
                SquareBtn(if (vault) "🔓" else "🔒", accent, ui) { if (vault) onVault(false) else askPin = true }
                Spacer(Modifier.width(8.dp))
                SquareBtn("✕", accent, ui, onClick = onClose)
            }
            Spacer(Modifier.height(6.dp))
            MonoText(
                if (vault) "// COFRE · apps ocultos · segure para gerenciar" else "segure um app: fixar ou ocultar",
                color = if (vault) accent else Cy.Dim, size = 10, bold = vault
            )
            Spacer(Modifier.height(8.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(cols),
                contentPadding = PaddingValues(bottom = 20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(apps, key = { it.component.flattenToString() }) { app ->
                    val pinned = pinnedKeys.contains(app.component.flattenToString())
                    Column(
                        Modifier.pointerInput(app.component) {
                            detectTapGestures(
                                onTap = { onLaunch(app) },
                                onLongPress = { menuApp = app }
                            )
                        },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Image(app.icon, app.label, Modifier.size(iconDp.dp))
                        Spacer(Modifier.height(3.dp))
                        MonoText(
                            (if (pinned) "◆ " else "") + app.label,
                            color = if (pinned) accent else Cy.Text.copy(alpha = 0.85f),
                            size = labelSize, align = TextAlign.Center
                        )
                    }
                }
            }
        }

        // ---- Menu do app (toque longo)
        val m = menuApp
        if (m != null) {
            Box(
                Modifier.fillMaxSize().background(Color(0x99000000)).clickable { menuApp = null },
                contentAlignment = Alignment.BottomCenter
            ) {
                CyberPanel(
                    Modifier.fillMaxWidth().navigationBarsPadding().padding(14.dp).clickable { },
                    ui, accent, title = m.label.uppercase()
                ) {
                    val isPinned = pinnedKeys.contains(m.component.flattenToString())
                    if (!vault) {
                        CyberButton(
                            if (isPinned) "DESAFIXAR DOS ATALHOS" else "FIXAR NOS ATALHOS",
                            accent, ui, Modifier.fillMaxWidth()
                        ) { onTogglePin(m); menuApp = null }
                        Spacer(Modifier.height(8.dp))
                    }
                    CyberButton(
                        if (vault) "TIRAR DO COFRE (MOSTRAR)" else "OCULTAR APP (COFRE)",
                        accent, ui, Modifier.fillMaxWidth()
                    ) { onToggleHidden(m); menuApp = null }
                    Spacer(Modifier.height(8.dp))
                    CyberButton("CANCELAR", accent, ui, Modifier.fillMaxWidth(), filled = true) { menuApp = null }
                }
            }
        }

        // ---- Senha
        if (askPin) {
            Box(
                Modifier.fillMaxSize().background(Color(0xF2020409)).clickable { },
                contentAlignment = Alignment.Center
            ) {
                PinPad(
                    title = "SENHA", accent = accent, ui = ui, length = pinLength,
                    onSubmit = { p -> if (checkPin(p)) { askPin = false; onVault(true); true } else false },
                    onCancel = { askPin = false }
                )
            }
        }
    }
}

@Composable
private fun SquareBtn(glyph: String, accent: Color, ui: UiPrefs, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(SmallCut)
            .border(1.dp, accent.copy(alpha = ui.line(0.8f)), SmallCut)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { MonoText(glyph, color = accent, size = 16, bold = true) }
}
