package com.noa.launcher.wallpaper

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.SurfaceHolder
import com.noa.launcher.settings.NoaPrefs
import com.noa.launcher.settings.WallpaperStore
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.random.Random

/**
 * Wallpaper reativo ao movimento (leve):
 *  - fundo pré-renderizado UMA vez em Bitmap (grade cibernética ou imagem da galeria) → por frame só há um drawBitmap
 *  - limitado a ~30 fps, canvas por hardware, sensor em SENSOR_DELAY_UI
 *  - só consome sensor/CPU enquanto está visível
 */
class MotionWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ParallaxEngine()

    private class Bit(var x: Float, var y: Float, val len: Float, val depth: Float, val alpha: Int, val speed: Float)

    private inner class ParallaxEngine : Engine(), SensorEventListener, Choreographer.FrameCallback {

        private val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        private val choreographer = Choreographer.getInstance()
        private val main = Handler(Looper.getMainLooper())
        private val io = Executors.newSingleThreadExecutor()
        private val prefs: SharedPreferences = NoaPrefs.get(applicationContext)

        private val bitPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG)

        private var w = 0
        private var h = 0
        private var visible = false
        private var lastFrame = 0L
        private var forceDraw = true

        private var gx = 0f; private var gy = 0f
        private var targetX = 0f; private var targetY = 0f
        private var curX = 0f; private var curY = 0f

        private var sens = 0.5f
        private var showBits = true
        private var mode = "cyber"
        private var version = 0L
        private var accentIdx = 0

        private var bg: Bitmap? = null
        private val bits = ArrayList<Bit>()

        private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
            if (readPrefs()) rebuildBackground()
            forceDraw = true
        }

        init {
            readPrefs()
            prefs.registerOnSharedPreferenceChangeListener(prefListener)
        }

        /** @return true se o fundo precisa ser refeito */
        private fun readPrefs(): Boolean {
            val m = prefs.getString(NoaPrefs.KEY_WP_MODE, "cyber") ?: "cyber"
            val v = prefs.getLong(NoaPrefs.KEY_WP_VERSION, 0L)
            val a = prefs.getInt(NoaPrefs.KEY_ACCENT, 0).coerceIn(0, NoaPrefs.ACCENTS.size - 1)
            sens = prefs.getFloat(NoaPrefs.KEY_SENSITIVITY, 0.5f)
            val lite = prefs.getBoolean(NoaPrefs.KEY_LITE, true)
            showBits = prefs.getBoolean(NoaPrefs.KEY_PARTICLES, true) && !lite
            val changed = m != mode || v != version || a != accentIdx
            mode = m; version = v; accentIdx = a
            return changed
        }

        // ---------- Ciclo de vida ----------
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width; h = height
            seedBits()
            rebuildBackground()
            forceDraw = true
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                if (readPrefs()) rebuildBackground()
                accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
                forceDraw = true
                choreographer.postFrameCallback(this)
            } else {
                sm.unregisterListener(this)
                choreographer.removeFrameCallback(this)
            }
        }

        override fun onDestroy() {
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
            sm.unregisterListener(this)
            choreographer.removeFrameCallback(this)
            io.shutdownNow()
            bg = null
            super.onDestroy()
        }

        // ---------- Sensor ----------
        override fun onSensorChanged(e: SensorEvent) {
            val a = 0.12f
            gx += a * (e.values[0] - gx)
            gy += a * (e.values[1] - gy)
            targetX = (-gx / 9.81f).coerceIn(-1f, 1f)
            targetY = (gy / 9.81f).coerceIn(-1f, 1f)
        }
        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) = Unit

        // ---------- Loop (~30 fps) ----------
        override fun doFrame(frameTimeNanos: Long) {
            if (!visible) return
            choreographer.postFrameCallback(this)
            if (frameTimeNanos - lastFrame < 28_000_000L) return
            lastFrame = frameTimeNanos

            curX += (targetX - curX) * 0.12f
            curY += (targetY - curY) * 0.12f
            val moving = abs(targetX - curX) > 0.0008f || abs(targetY - curY) > 0.0008f
            if (!moving && !showBits && !forceDraw) return   // nada mudou: não gasta bateria
            forceDraw = false
            draw()
        }

        private fun draw() {
            val bmp = bg
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = try { holder.lockHardwareCanvas() } catch (e: Exception) { holder.lockCanvas() }
                if (c == null) return
                c.drawColor(0xFF05070D.toInt())
                val maxShift = w * 0.06f * (0.3f + sens * 1.7f)

                if (bmp != null) {
                    c.drawBitmap(
                        bmp,
                        -w * 0.1f - curX * maxShift * 0.35f,
                        -h * 0.1f - curY * maxShift * 0.35f,
                        bmpPaint
                    )
                }

                if (showBits) {
                    bitPaint.color = NoaPrefs.ACCENTS[accentIdx]
                    for (b in bits) {
                        b.y += b.speed
                        if (b.y > h + b.len) { b.y = -b.len; b.x = Random.nextFloat() * w }
                        bitPaint.alpha = b.alpha
                        val x = b.x - curX * maxShift * b.depth * 1.6f
                        val y = b.y - curY * maxShift * b.depth * 1.6f
                        c.drawRect(x, y, x + 2f + b.depth * 2f, y + b.len, bitPaint)
                    }
                }
            } finally {
                if (c != null) holder.unlockCanvasAndPost(c)
            }
        }

        private fun seedBits() {
            bits.clear()
            if (w <= 0) return
            repeat(18) {
                val d = 0.2f + Random.nextFloat() * 0.8f
                bits += Bit(
                    x = Random.nextFloat() * w, y = Random.nextFloat() * h,
                    len = 14f + d * 40f, depth = d,
                    alpha = (25 + d * 90).toInt(), speed = 1.2f + d * 4f
                )
            }
        }

        // ---------- Fundo pré-renderizado (fora da thread principal) ----------
        private fun rebuildBackground() {
            if (w <= 0 || h <= 0) return
            val bw = (w * 1.2f).toInt()
            val bh = (h * 1.2f).toInt()
            val m = mode
            val acc = NoaPrefs.ACCENTS[accentIdx]
            val acc2 = NoaPrefs.ACCENTS[(accentIdx + 1) % NoaPrefs.ACCENTS.size]
            io.execute {
                val result = try {
                    if (m == "image") buildImage(bw, bh) ?: buildCyber(bw, bh, acc, acc2)
                    else buildCyber(bw, bh, acc, acc2)
                } catch (e: Throwable) { null }
                main.post {
                    val old = bg
                    bg = result
                    forceDraw = true
                    if (old != null && old !== result) old.recycle()
                }
            }
        }

        private fun buildCyber(bw: Int, bh: Int, acc: Int, acc2: Int): Bitmap {
            val bmp = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.shader = LinearGradient(
                0f, 0f, 0f, bh.toFloat(),
                intArrayOf(0xFF05070D.toInt(), 0xFF0A1426.toInt(), 0xFF05070D.toInt()),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
            p.shader = null

            // grade
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1f
            val step = 72f
            p.color = (acc and 0x00FFFFFF) or (0x1C shl 24)
            var x = 0f
            while (x < bw) { c.drawLine(x, 0f, x, bh.toFloat(), p); x += step }
            var y = 0f
            while (y < bh) { c.drawLine(0f, y, bw.toFloat(), y, p); y += step }
            // linhas mestras
            p.strokeWidth = 2f
            p.color = (acc and 0x00FFFFFF) or (0x30 shl 24)
            x = 0f
            while (x < bw) { c.drawLine(x, 0f, x, bh.toFloat(), p); x += step * 4 }
            y = 0f
            while (y < bh) { c.drawLine(0f, y, bw.toFloat(), y, p); y += step * 4 }

            // brilhos
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(bw * 0.8f, bh * 0.25f, bw * 0.7f,
                (acc and 0x00FFFFFF) or (0x38 shl 24), 0x00000000, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
            p.shader = RadialGradient(bw * 0.1f, bh * 0.85f, bw * 0.8f,
                (acc2 and 0x00FFFFFF) or (0x28 shl 24), 0x00000000, Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, bw.toFloat(), bh.toFloat(), p)
            return bmp
        }

        private fun buildImage(bw: Int, bh: Int): Bitmap? {
            val f = WallpaperStore.file(applicationContext)
            if (!f.exists()) return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= bw && bounds.outHeight / (sample * 2) >= bh) sample *= 2
            val src = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            val out = Bitmap.createBitmap(bw, bh, Bitmap.Config.RGB_565)
            val c = Canvas(out)
            // center-crop
            val scale = maxOf(bw / src.width.toFloat(), bh / src.height.toFloat())
            val m = Matrix()
            m.postScale(scale, scale)
            m.postTranslate((bw - src.width * scale) / 2f, (bh - src.height * scale) / 2f)
            c.drawBitmap(src, m, Paint(Paint.FILTER_BITMAP_FLAG))
            src.recycle()
            // véu escuro p/ manter textos legíveis
            c.drawColor(0x66000000)
            return out
        }
    }
}
