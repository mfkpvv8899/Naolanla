package com.noa.launcher.home

import android.animation.ValueAnimator
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.noa.launcher.settings.SettingsActivity

class HomeActivity : ComponentActivity() {

    private val vm: HomeViewModel by viewModels()
    private var blurAnimator: ValueAnimator? = null
    private var currentBlur = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { vm.closeDrawer() }
        })

        setContent {
            val open by vm.drawerOpen.collectAsState()
            val ui by vm.ui.collectAsState()

            // Blur animado FORA da composição (não recompõe a tela a cada frame = bem mais leve)
            LaunchedEffect(open, ui.blurRadiusPx, ui.lite) { animateBlur(if (open && !ui.lite) ui.blurRadiusPx else 0) }

            HomeScreen(
                vm = vm,
                onSwipeDown = ::expandNotifications,
                onSettings = { startActivity(Intent(this, SettingsActivity::class.java)) },
                onGrantMedia = {
                    try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
                },
                onHaptic = { window.decorView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
            )
        }
    }

    override fun onStart() {
        super.onStart()
        vm.media.start()
        vm.refreshSys()
    }

    override fun onStop() {
        vm.media.stop()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) vm.closeDrawer()
    }

    private fun animateBlur(target: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        blurAnimator?.cancel()
        blurAnimator = ValueAnimator.ofInt(currentBlur, target).apply {
            duration = 220
            addUpdateListener {
                currentBlur = it.animatedValue as Int
                window.setBackgroundBlurRadius(currentBlur)
            }
            start()
        }
    }

    /** Requer EXPAND_STATUS_BAR. API oculta via reflection. */
    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) { }
    }
}
