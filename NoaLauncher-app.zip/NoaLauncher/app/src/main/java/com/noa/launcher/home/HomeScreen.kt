package com.noa.launcher.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import com.noa.launcher.drawer.AppDrawer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    onSwipeDown: () -> Unit,
    onLongPress: () -> Unit,
    onDoubleTap: () -> Unit,
    onHaptic: () -> Unit
) {
    val drawerOpen by vm.drawerOpen.collectAsState()
    val apps by vm.apps.collectAsState()
    val dock by vm.dock.collectAsState()
    val query by vm.query.collectAsState()
    val ui by vm.ui.collectAsState()

    Box(
        Modifier
            .fillMaxSize() // fundo 100% transparente: o wallpaper vem da janela
            .pointerInput(Unit) {
                detectTapGestures(
                    onDoubleTap = { onDoubleTap() },
                    onLongPress = { onHaptic(); onLongPress() }
                )
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = {
                        if (total < -120f) { onHaptic(); vm.openDrawer() }
                        else if (total > 120f) onSwipeDown()
                    }
                )
            }
    ) {
        // Relógio minimalista
        val time = remember { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) }
        Column(
            Modifier.align(Alignment.TopStart).statusBarsPadding().padding(start = 28.dp, top = 72.dp)
        ) {
            Text(time, color = Color.White, fontSize = 72.sp, fontWeight = FontWeight.ExtraLight)
        }

        // Dock translúcido
        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(horizontal = 24.dp, vertical = 20.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White.copy(alpha = ui.glass(0.10f)))
                .padding(horizontal = 20.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            dock.forEach { app ->
                Image(app.icon, app.label, Modifier.size(48.dp).clickable { onHaptic(); vm.launch(app) })
            }
        }

        // App drawer
        AnimatedVisibility(
            visible = drawerOpen,
            enter = slideInVertically(tween(280)) { it / 3 } + fadeIn(tween(280)),
            exit = slideOutVertically(tween(220)) { it / 3 } + fadeOut(tween(220))
        ) {
            AppDrawer(
                apps = apps, query = query, ui = ui,
                onQuery = { vm.query.value = it },
                onLaunch = vm::launch
            )
        }
    }
}
