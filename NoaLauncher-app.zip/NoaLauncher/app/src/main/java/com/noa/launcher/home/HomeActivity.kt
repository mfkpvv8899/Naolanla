package com.noa.launcher.home

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.noa.launcher.settings.SettingsActivity

class HomeActivity : ComponentActivity() {

    private val vm: HomeViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()              // status e navigation bar transparentes
        super.onCreate(savedInstanceState)

        // Voltar fecha o drawer; na home, não faz nada (comportamento de launcher)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { vm.closeDrawer() }
        })

        setContent {
            val open by vm.drawerOpen.collectAsState()
            val ui by vm.ui.collectAsState()
            // Blur real do que está ATRÁS da janela (o wallpaper). API 31+; abaixo disso fica só o véu escuro.
            val radius by animateIntAsState(if (open) ui.blurRadiusPx else 0, tween(300), label = "blur")
            LaunchedEffect(radius) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) window.setBackgroundBlurRadius(radius)
            }

            HomeScreen(
                vm = vm,
                onSwipeDown = ::expandNotifications,
                onLongPress = { startActivity(Intent(this, SettingsActivity::class.java)) },
                onDoubleTap = ::lockScreen,
                onHaptic = { window.decorView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) vm.closeDrawer() // botão Home volta ao início
    }

    override fun onResume() { super.onResume(); vm.refresh() }

    /** Requer a permissão EXPAND_STATUS_BAR. API oculta, via reflection. */
    private fun expandNotifications() {
        runCatching {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager")
                .getMethod("expandNotificationsPanel").invoke(sb)
        }
    }

    /**
     * Bloquear a tela via double tap exige um AccessibilityService com
     * performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) (API 28+). Stub para a próxima etapa.
     */
    private fun lockScreen() {
        // TODO: NoaAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN)
    }
}
