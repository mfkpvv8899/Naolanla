package com.noa.launcher.wallpaper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.SurfaceHolder
import com.noa.launcher.settings.NoaPrefs
import kotlin.math.max
import kotlin.random.Random

/**
 * Live wallpaper com parallax por acelerômetro.
 *
 * Pipeline: sensor → low-pass (suaviza ruído) → alvo (target) → lerp por frame → camadas com profundidades diferentes.
 * O sensor só fica registrado enquanto o wallpaper está visível (tela ligada), para economizar bateria.
 */
class MotionWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine = ParallaxEngine()

    private class Particle(
        var x: Float, var y: Float,
        val radius: Float, val depth: Float, // depth 0.2 (longe) .. 1.0 (perto)
        val alpha: Int, val speed: Float
    )

    private inner class ParallaxEngine : Engine(), SensorEventListener, Choreographer.FrameCallback {

        private val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        private val choreographer = Choreographer.getInstance()

        private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }

        private var w = 0
        private var h = 0
        private var visible = false

        // Estado do movimento (-1..1)
        private var gx = 0f; private var gy = 0f   // gravidade filtrada
        private var targetX = 0f; private var targetY = 0f
        private var curX = 0f; private var curY = 0f

        private var sensitivity = 0.5f
        private var showParticles = true
        private val particles = ArrayList<Particle>()

        // ---------- Ciclo de vida ----------
        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            w = width; h = height
            // Fundo 20% maior que a tela para ter "margem" de parallax
            bgPaint.shader = LinearGradient(
                0f, 0f, 0f, h * 1.2f,
                intArrayOf(0xFF0B0B0D.toInt(), 0xFF16171B.toInt(), 0xFF0B0B0D.toInt()),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            seedParticles()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                sensitivity = NoaPrefs.sensitivity(applicationContext)
                showParticles = NoaPrefs.particles(applicationContext)
                accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
                choreographer.postFrameCallback(this)
            } else {
                sm.unregisterListener(this)
                choreographer.removeFrameCallback(this)
            }
        }

        override fun onDestroy() {
            sm.unregisterListener(this)
            choreographer.removeFrameCallback(this)
            super.onDestroy()
        }

        // ---------- Sensor ----------
        override fun onSensorChanged(e: SensorEvent) {
            val a = 0.12f // low-pass: menor = mais suave, mais lento
            gx += a * (e.values[0] - gx)
            gy += a * (e.values[1] - gy)
            // Normaliza por 1g (~9.81) e limita a ±1. Inclinar p/ direita move camadas p/ esquerda.
            targetX = (-gx / 9.81f).coerceIn(-1f, 1f)
            targetY = ( gy / 9.81f).coerceIn(-1f, 1f)
        }
        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) = Unit

        // ---------- Render ----------
        override fun doFrame(frameTimeNanos: Long) {
            if (!visible) return
            // Lerp: aproxima o valor atual do alvo (física suave, sem trepidação)
            curX += (targetX - curX) * 0.08f
            curY += (targetY - curY) * 0.08f
            draw()
            choreographer.postFrameCallback(this)
        }

        private fun draw() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                c = holder.lockCanvas() ?: return
                // Amplitude máxima do deslocamento, regulada pela sensibilidade (0..1)
                val maxShift = w * 0.06f * (0.3f + sensitivity * 1.7f)

                // Camada 0: fundo (movimento mínimo)
                c.save()
                c.translate(curX * maxShift * 0.25f, -h * 0.1f + curY * maxShift * 0.25f)
                c.drawRect(-w * 0.1f, 0f, w * 1.1f, h * 1.2f, bgPaint)
                c.restore()

                // Camadas 1..n: partículas flutuantes, cada uma com sua profundidade
                if (showParticles) {
                    for (p in particles) {
                        p.y -= p.speed
                        if (p.y + p.radius < 0) { p.y = h + p.radius; p.x = Random.nextFloat() * w }
                        dotPaint.alpha = p.alpha
                        c.drawCircle(
                            p.x + curX * maxShift * p.depth * 2f,
                            p.y + curY * maxShift * p.depth * 2f,
                            p.radius, dotPaint
                        )
                    }
                }
            } finally {
                c?.let { holder.unlockCanvasAndPost(it) }
            }
        }

        private fun seedParticles() {
            particles.clear()
            repeat(28) {
                val depth = 0.2f + Random.nextFloat() * 0.8f
                particles += Particle(
                    x = Random.nextFloat() * w,
                    y = Random.nextFloat() * h,
                    radius = max(2f, depth * 9f),
                    depth = depth,
                    alpha = (30 + depth * 90).toInt(),
                    speed = 0.1f + depth * 0.35f
                )
            }
        }
    }
}
