package com.noa.launcher.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.noa.launcher.settings.UiPrefs

object Cy {
    val Bg = Color(0xFF05070D)
    val Panel = Color(0xFF0A1424)
    val Text = Color(0xFFE6F7FF)
    val Dim = Color(0xFF7FA3B8)
}

val CutShape = CutCornerShape(topStart = 0.dp, topEnd = 14.dp, bottomEnd = 0.dp, bottomStart = 14.dp)
val SmallCut = CutCornerShape(topStart = 0.dp, topEnd = 8.dp, bottomEnd = 0.dp, bottomStart = 8.dp)

@Composable
fun MonoText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Cy.Dim,
    size: Int = 11,
    bold: Boolean = false,
    maxLines: Int = 1,
    spacing: Int = 0,
    align: TextAlign? = null
) {
    Text(
        text = text,
        modifier = modifier,
        color = color,
        fontFamily = FontFamily.Monospace,
        fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        letterSpacing = spacing.sp,
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
        textAlign = align
    )
}

/** Painel HUD: canto cortado + borda neon + título "// ASSIM". Respeita o modo "tudo transparente". */
@Composable
fun CyberPanel(
    modifier: Modifier = Modifier,
    ui: UiPrefs,
    accent: Color,
    title: String? = null,
    shape: Shape = CutShape,
    padding: Dp = 12.dp,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val base = modifier
        .clip(shape)
        .background(Cy.Panel.copy(alpha = ui.glass(0.62f)))
        .border(1.dp, accent.copy(alpha = ui.line(0.6f)), shape)
    val m = if (onClick != null) base.clickable(onClick = onClick) else base
    Column(m.padding(padding)) {
        if (title != null) {
            MonoText("// $title", color = accent, size = 10, bold = true, spacing = 2)
            Spacer(Modifier.height(6.dp))
        }
        content()
    }
}

@Composable
fun CyberButton(
    text: String,
    accent: Color,
    ui: UiPrefs,
    modifier: Modifier = Modifier,
    filled: Boolean = false,
    onClick: () -> Unit
) {
    Box(
        modifier
            .clip(SmallCut)
            .background(if (filled) accent.copy(alpha = ui.glass(0.18f)) else Color.Transparent)
            .border(1.dp, accent.copy(alpha = ui.line(0.7f)), SmallCut)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        MonoText(text, color = accent, size = 12, bold = true, spacing = 1)
    }
}
