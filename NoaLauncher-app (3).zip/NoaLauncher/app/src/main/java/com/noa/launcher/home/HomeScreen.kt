package com.noa.launcher.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import com.noa.launcher.drawer.AppDrawer
import com.noa.launcher.drawer.AppInfo
import com.noa.launcher.info.BatteryInfo
import com.noa.launcher.info.SysInfo
import com.noa.launcher.info.Weather
import com.noa.launcher.info.WeatherRepository
import com.noa.launcher.media.MediaRepository
import com.noa.launcher.media.MediaState
import com.noa.launcher.settings.UiPrefs
import com.noa.launcher.ui.CyberButton
import com.noa.launcher.ui.CyberPanel
import com.noa.launcher.ui.Cy
import com.noa.launcher.ui.MonoText
import com.noa.launcher.ui.SmallCut
import com.noa.launcher.util.Launch
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private data class AiApp(val label: String, val pkg: String, val url: String)

private val AI_APPS = listOf(
    AiApp("GPT", "com.openai.chatgpt", "https://chatgpt.com"),
    AiApp("CLAUDE", "com.anthropic.claude", "https://claude.ai"),
    AiApp("GEMINI", "com.google.android.apps.bard", "https://gemini.google.com"),
    AiApp("COPILOT", "com.microsoft.copilot", "https://copilot.microsoft.com"),
    AiApp("PERPLEX", "ai.perplexity.app.android", "https://www.perplexity.ai")
)

@Composable
fun HomeScreen(
    vm: HomeViewModel,
    onSwipeDown: () -> Unit,
    onSettings: () -> Unit,
    onGrantMedia: () -> Unit,
    onHaptic: () -> Unit
) {
    val ctx = LocalContext.current
    val ui by vm.ui.collectAsState()
    val accent = Color(ui.accentArgb)
    val drawerOpen by vm.drawerOpen.collectAsState()
    val apps by vm.apps.collectAsState()
    val all by vm.all.collectAsState()
    val pinned by vm.pinned.collectAsState()
    val pinnedKeys by vm.pinnedKeys.collectAsState()
    val query by vm.query.collectAsState()
    val weather by vm.weather.collectAsState()
    val city by vm.city.collectAsState()
    val battery by vm.battery.collectAsState()
    val sys by vm.sys.collectAsState()
    val media by vm.media.state.collectAsState()
    val vault by vm.showHidden.collectAsState()

    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { if (!vm.drawerOpen.value) { onHaptic(); onSettings() } })
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onVerticalDrag = { _, dy -> total += dy },
                    onDragEnd = {
                        val open = vm.drawerOpen.value
                        if (total < -120f && !open) { onHaptic(); vm.openDrawer() }
                        else if (total > 120f && !open) onSwipeDown()
                    }
                )
            }
    ) {
        if (!drawerOpen) Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ClockHeader(city.name, accent)
            WeatherPanel(weather, ui, accent)
            StatusRow(battery, sys, ui, accent)
            MusicPanel(
                m = media, ui = ui, accent = accent,
                onPrev = { onHaptic(); vm.media.previous() },
                onPlay = { onHaptic(); vm.media.playPause() },
                onNext = { onHaptic(); vm.media.next() },
                onOpen = { Launch.pkgOrWeb(ctx, media.pkg ?: MediaRepository.SPOTIFY, "https://open.spotify.com") },
                onGrant = onGrantMedia
            )
            AiRow(all, ui, accent) { onHaptic(); Launch.pkgOrWeb(ctx, it.pkg, it.url) }
            ShortcutsPanel(pinned, ui, accent) { onHaptic(); vm.launch(it) }

            Spacer(Modifier.weight(1f))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CyberButton("▲  APPS", accent, ui, Modifier.weight(1f), filled = true) { onHaptic(); vm.openDrawer() }
                CyberButton("⚙", accent, ui) { onSettings() }
            }
        }

        // Com o drawer aberto a tela inicial NÃO é desenhada (não aparece atrás e fica mais leve)
        if (drawerOpen) {
            AppDrawer(
                apps = apps, query = query, ui = ui, accent = accent,
                pinnedKeys = pinnedKeys, vault = vault, pinLength = vm.pinLength(),
                onQuery = { vm.query.value = it },
                onLaunch = vm::launch,
                onTogglePin = { onHaptic(); vm.togglePin(it) },
                onToggleHidden = { onHaptic(); vm.toggleHidden(it) },
                checkPin = vm::checkPin,
                onVault = vm::setVault,
                onClose = vm::closeDrawer
            )
        }
    }
}

// ---------------------------------------------------------------- Relógio
@Composable
private fun ClockHeader(city: String, accent: Color) {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            val t = System.currentTimeMillis()
            now = t
            delay(60_000L - t % 60_000L + 50L)   // acorda 1x por minuto
        }
    }
    val hm = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val date = remember { SimpleDateFormat("EEE dd MMM", Locale("pt", "BR")) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
        Column {
            Text(
                hm.format(Date(now)), color = Cy.Text, fontFamily = FontFamily.Monospace,
                fontSize = 54.sp, fontWeight = FontWeight.Light
            )
            MonoText(date.format(Date(now)).uppercase(), color = accent, size = 12, bold = true, spacing = 2)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            MonoText("NÔA//OS", color = accent, size = 11, bold = true, spacing = 3)
            MonoText("LOC: ${city.uppercase()}", color = Cy.Dim, size = 10)
        }
    }
}

// ---------------------------------------------------------------- Clima
@Composable
private fun WeatherPanel(w: Weather?, ui: UiPrefs, accent: Color) {
    CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "CLIMA") {
        if (w == null) {
            MonoText("SINCRONIZANDO COM SATÉLITE...", color = Cy.Dim, size = 12)
        } else {
            val (glyph, desc) = WeatherRepository.describe(w.code, w.isDay)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("${w.temp}°", color = Cy.Text, fontFamily = FontFamily.Monospace, fontSize = 40.sp, fontWeight = FontWeight.Light)
                Spacer(Modifier.width(10.dp))
                Text(glyph, color = accent, fontSize = 30.sp)
                Spacer(Modifier.weight(1f))
                Column(horizontalAlignment = Alignment.End) {
                    MonoText(desc, color = accent, size = 12, bold = true, spacing = 1)
                    MonoText("SENS ${w.feels}°  UMID ${w.humidity}%", size = 10)
                    MonoText("VENTO ${w.wind}km/h  ☂${w.rain}%", size = 10)
                    MonoText("MIN ${w.min}°  MAX ${w.max}°", size = 10)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Status
@Composable
private fun StatusRow(b: BatteryInfo, s: SysInfo, ui: UiPrefs, accent: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        val bat = if (b.level >= 0) "${b.level}%" + (if (b.charging) " ⚡" else "") else "—"
        Chip("BATERIA", bat, ui, accent, Modifier.weight(1f))
        Chip("ARMAZ.", "${s.storageFreeGb}G livres", ui, accent, Modifier.weight(1f))
        Chip("REDE", s.net, ui, accent, Modifier.weight(1f))
    }
}

@Composable
private fun Chip(label: String, value: String, ui: UiPrefs, accent: Color, modifier: Modifier) {
    CyberPanel(modifier, ui, accent, shape = SmallCut, padding = 8.dp) {
        MonoText(label, color = Cy.Dim, size = 9, spacing = 1)
        MonoText(value, color = Cy.Text, size = 13, bold = true)
    }
}

// ---------------------------------------------------------------- Música
@Composable
private fun MusicPanel(
    m: MediaState, ui: UiPrefs, accent: Color,
    onPrev: () -> Unit, onPlay: () -> Unit, onNext: () -> Unit,
    onOpen: () -> Unit, onGrant: () -> Unit
) {
    CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "ÁUDIO") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(SmallCut).border(1.dp, accent.copy(alpha = 0.5f), SmallCut),
                contentAlignment = Alignment.Center
            ) {
                val art = m.art
                if (art != null) Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else MonoText("♪", color = accent, size = 20)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f).clickable(onClick = onOpen)) {
                MonoText(m.title ?: "Nenhuma mídia tocando", color = Cy.Text, size = 13, bold = true)
                MonoText(
                    if (m.hasAccess) (m.artist ?: "toque para abrir o Spotify") else "faixa oculta · ative a leitura",
                    color = Cy.Dim, size = 10
                )
            }
            Ctl("⏮", accent, onPrev)
            Ctl(if (m.playing) "⏸" else "▶", accent, onPlay)
            Ctl("⏭", accent, onNext)
        }
        if (!m.hasAccess) {
            Spacer(Modifier.size(6.dp))
            CyberButton("ATIVAR LEITURA DA FAIXA", accent, ui, Modifier.fillMaxWidth(), onClick = onGrant)
        }
    }
}

@Composable
private fun Ctl(glyph: String, accent: Color, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Text(glyph, color = accent, fontSize = 22.sp)
    }
}

// ---------------------------------------------------------------- IA
@Composable
private fun AiRow(all: List<AppInfo>, ui: UiPrefs, accent: Color, onOpen: (AiApp) -> Unit) {
    val byPkg = remember(all) { all.associateBy { it.component.packageName } }
    CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "I.A.", padding = 10.dp) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            AI_APPS.forEach { ai ->
                Column(
                    Modifier.weight(1f).clickable { onOpen(ai) },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val icon = byPkg[ai.pkg]?.icon
                    if (icon != null) {
                        Image(icon, ai.label, Modifier.size(34.dp))
                    } else {
                        Box(
                            Modifier.size(34.dp).clip(SmallCut).border(1.dp, accent.copy(alpha = 0.6f), SmallCut),
                            contentAlignment = Alignment.Center
                        ) { MonoText(ai.label.take(1), color = accent, size = 16, bold = true) }
                    }
                    Spacer(Modifier.size(3.dp))
                    MonoText(ai.label, color = Cy.Dim, size = 8, align = TextAlign.Center)
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Atalhos
@Composable
private fun ShortcutsPanel(pinned: List<AppInfo>, ui: UiPrefs, accent: Color, onOpen: (AppInfo) -> Unit) {
    CyberPanel(Modifier.fillMaxWidth(), ui, accent, title = "ATALHOS", padding = 10.dp) {
        if (pinned.isEmpty()) {
            MonoText("vazio · segure um app no drawer ou use ⚙ → ATALHOS", color = Cy.Dim, size = 10)
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                pinned.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth()) {
                        row.forEach { app ->
                            Column(
                                Modifier.weight(1f).clickable { onOpen(app) },
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Image(app.icon, app.label, Modifier.size(38.dp))
                                MonoText(app.label, color = Cy.Text, size = 9, align = TextAlign.Center)
                            }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}
