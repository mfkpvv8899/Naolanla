package com.noa.launcher.media

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.view.KeyEvent
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class MediaState(
    val hasAccess: Boolean = false,
    val title: String? = null,
    val artist: String? = null,
    val playing: Boolean = false,
    val pkg: String? = null,
    val art: ImageBitmap? = null
)

class MediaRepository(private val ctx: Context) {

    companion object { const val SPOTIFY = "com.spotify.music" }

    private val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val listenerCn = ComponentName(ctx, NoaNotificationListener::class.java)
    private val _state = MutableStateFlow(MediaState())
    val state: StateFlow<MediaState> = _state

    private var controller: MediaController? = null
    private var registered = false
    private var artKey: String? = null
    private var artCache: ImageBitmap? = null

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { publish() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { publish() }
        override fun onSessionDestroyed() { controller = null; refresh() }
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> choose(list ?: emptyList()) }

    fun hasAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun start() {
        if (!hasAccess()) { _state.value = MediaState(hasAccess = false); return }
        try {
            if (!registered) {
                msm.addOnActiveSessionsChangedListener(sessionsListener, listenerCn)
                registered = true
            }
            refresh()
        } catch (e: SecurityException) {
            _state.value = MediaState(hasAccess = false)
        }
    }

    fun stop() {
        if (registered) {
            try { msm.removeOnActiveSessionsChangedListener(sessionsListener) } catch (e: Exception) { }
            registered = false
        }
        controller?.unregisterCallback(callback)
        controller = null
    }

    private fun refresh() {
        try { choose(msm.getActiveSessions(listenerCn)) } catch (e: SecurityException) {
            _state.value = MediaState(hasAccess = false)
        }
    }

    private fun choose(list: List<MediaController>) {
        val best = list.firstOrNull { it.packageName == SPOTIFY }
            ?: list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        if (best?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = best
            controller?.registerCallback(callback)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        if (c == null) { _state.value = MediaState(hasAccess = true); return }
        val md = c.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
        val key = (title ?: "") + "|" + (artist ?: "")
        if (key != artKey) {
            val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            artCache = bmp?.let { Bitmap.createScaledBitmap(it, 96, 96, true).asImageBitmap() }
            artKey = key
        }
        _state.value = MediaState(
            hasAccess = true,
            title = title,
            artist = artist,
            playing = c.playbackState?.state == PlaybackState.STATE_PLAYING,
            pkg = c.packageName,
            art = artCache
        )
    }

    // ---- Controles: usam a sessão se houver; senão, teclas de mídia (funciona sem permissão) ----
    fun playPause() {
        val c = controller
        if (c != null) {
            if (_state.value.playing) c.transportControls.pause() else c.transportControls.play()
        } else key(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    }

    fun next() {
        val c = controller
        if (c != null) c.transportControls.skipToNext() else key(KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun previous() {
        val c = controller
        if (c != null) c.transportControls.skipToPrevious() else key(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    private fun key(code: Int) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }
}
