package com.noa.launcher.home

import android.app.Application
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.noa.launcher.drawer.AppInfo
import com.noa.launcher.drawer.AppRepository
import com.noa.launcher.info.BatteryInfo
import com.noa.launcher.info.SysInfo
import com.noa.launcher.info.SystemInfo
import com.noa.launcher.info.Weather
import com.noa.launcher.info.WeatherRepository
import com.noa.launcher.media.MediaRepository
import com.noa.launcher.settings.NoaPrefs
import com.noa.launcher.settings.UiPrefs
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(private val app: Application) : AndroidViewModel(app) {

    private val repo = AppRepository(app)
    private val allApps = MutableStateFlow<List<AppInfo>>(emptyList())
    val all: StateFlow<List<AppInfo>> = allApps

    val ui: StateFlow<UiPrefs> = NoaPrefs.observe(app) { NoaPrefs.readUi(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, NoaPrefs.readUi(app))

    val query = MutableStateFlow("")
    val drawerOpen = MutableStateFlow(false)
    /** true = o drawer mostra só os apps ocultos (cofre), liberado pela senha */
    val showHidden = MutableStateFlow(false)

    val hiddenKeys: StateFlow<List<String>> = NoaPrefs.observe(app) { NoaPrefs.hidden(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, NoaPrefs.hidden(app))

    val apps: StateFlow<List<AppInfo>> = combine(allApps, query, hiddenKeys, showHidden) { list, q, hidden, vault ->
        val hiddenSet = hidden.toHashSet()
        list.filter { (hiddenSet.contains(it.component.flattenToString())) == vault }
            .filter { q.isBlank() || it.label.contains(q, ignoreCase = true) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val pinnedKeys: StateFlow<List<String>> = NoaPrefs.observe(app) { NoaPrefs.pinned(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, NoaPrefs.pinned(app))

    val pinned: StateFlow<List<AppInfo>> = combine(allApps, pinnedKeys, hiddenKeys) { list, keys, hidden ->
        val hiddenSet = hidden.toHashSet()
        keys.filter { !hiddenSet.contains(it) }
            .mapNotNull { k -> list.firstOrNull { it.component.flattenToString() == k } }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val city = NoaPrefs.observe(app) { NoaPrefs.readCity(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, NoaPrefs.readCity(app))

    val weather = MutableStateFlow<Weather?>(null)
    val battery: StateFlow<BatteryInfo> = SystemInfo.batteryFlow(app)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), BatteryInfo())
    val sys = MutableStateFlow(SysInfo())
    val media = MediaRepository(app)

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) { refreshApps() }
    }

    init {
        refreshApps()
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(app, pkgReceiver, f, ContextCompat.RECEIVER_EXPORTED)

        viewModelScope.launch {
            city.collectLatest { c ->
                while (true) {
                    val w = WeatherRepository.fetch(c)
                    if (w != null) weather.value = w
                    delay(if (w == null) 120_000L else 1_800_000L)
                }
            }
        }
    }

    fun refreshApps() { viewModelScope.launch { allApps.value = repo.loadApps() } }
    fun refreshSys() { sys.value = SystemInfo.read(app) }

    fun launch(a: AppInfo) { repo.launch(a); closeDrawer() }
    fun openDrawer() { drawerOpen.value = true }
    fun closeDrawer() { drawerOpen.value = false; query.value = ""; showHidden.value = false }

    // ---- senha / cofre ----
    fun pinLength(): Int = NoaPrefs.pin(app).length
    fun checkPin(p: String): Boolean = p == NoaPrefs.pin(app)
    fun setVault(on: Boolean) { showHidden.value = on; query.value = "" }

    fun toggleHidden(a: AppInfo) {
        val list = NoaPrefs.hidden(app).toMutableList()
        val k = a.component.flattenToString()
        if (!list.remove(k)) list.add(k)
        NoaPrefs.setHidden(app, list)
    }

    /** Fixa/desafixa um app nos atalhos. Retorna false se atingiu o limite. */
    fun togglePin(a: AppInfo): Boolean {
        val list = NoaPrefs.pinned(app).toMutableList()
        val k = a.component.flattenToString()
        if (!list.remove(k)) {
            if (list.size >= NoaPrefs.MAX_PINNED) return false
            list.add(k)
        }
        NoaPrefs.setPinned(app, list)
        return true
    }

    override fun onCleared() {
        try { app.unregisterReceiver(pkgReceiver) } catch (e: Exception) { }
        media.stop()
    }
}
