package com.noa.launcher.ui

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.noa.launcher.settings.UiPrefs

/** Teclado numérico estilo HUD. Envia automaticamente ao completar [length] dígitos. */
@Composable
fun PinPad(
    title: String,
    accent: Color,
    ui: UiPrefs,
    length: Int,
    onSubmit: (String) -> Boolean,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var pin by remember { mutableStateOf("") }
    var err by remember { mutableStateOf(false) }

    fun push(d: String) {
        if (pin.length >= length) return
        pin += d
        err = false
        if (pin.length == length) {
            val ok = onSubmit(pin)
            if (!ok) err = true
            pin = ""
        }
    }

    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        MonoText("// $title", color = accent, size = 18, bold = true, spacing = 3)
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(length) { i ->
                MonoText(if (i < pin.length) "●" else "○", color = accent, size = 24)
            }
        }
        Spacer(Modifier.height(6.dp))
        MonoText(if (err) "SENHA INCORRETA" else " ", color = Color(0xFFFF4D6D), size = 11, bold = true)
        Spacer(Modifier.height(10.dp))

        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9"), listOf("⌫", "0", "✕"))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            rows.forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { k ->
                        Box(
                            Modifier.width(76.dp).height(54.dp).clip(SmallCut)
                                .border(1.dp, accent.copy(alpha = ui.line(0.65f)), SmallCut)
                                .clickable {
                                    when (k) {
                                        "⌫" -> { pin = pin.dropLast(1); err = false }
                                        "✕" -> onCancel()
                                        else -> push(k)
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) { MonoText(k, color = accent, size = 20, bold = true) }
                    }
                }
            }
        }
    }
}
