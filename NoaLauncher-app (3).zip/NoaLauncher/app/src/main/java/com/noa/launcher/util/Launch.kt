package com.noa.launcher.util

import android.content.Context
import android.content.Intent
import android.net.Uri

object Launch {
    /** Abre o app pelo pacote; se não estiver instalado, abre o site no navegador. */
    fun pkgOrWeb(ctx: Context, pkg: String, url: String) {
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg)
            ?: Intent(Intent.ACTION_VIEW, Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try { ctx.startActivity(intent) } catch (e: Exception) { /* ignora */ }
    }
}
