package com.noa.launcher.settings

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

data class UiPrefs(
    val transparentMode: Boolean = false,
    val transparency: Float = 0.7f,
    val blur: Float = 0.6f,
    val accent: Int = 0,
    val columns: Int = 5,          // colunas do drawer (4..6)
    val lite: Boolean = true       // modo leve: sem partículas e sem blur de janela
) {
    /** Alpha final de superfícies (fundos) conforme o modo "tudo transparente". */
    fun glass(base: Float): Float = if (transparentMode) base * (1f - transparency) else base

    /** Alpha de bordas/linhas neon (some mais devagar para manter o visual HUD). */
    fun line(base: Float): Float = if (transparentMode) base * (1f - transparency * 0.7f) else base

    val blurRadiusPx: Int get() = (blur * 150f).toInt()
    val accentArgb: Int get() = NoaPrefs.ACCENTS[accent.coerceIn(0, NoaPrefs.ACCENTS.size - 1)]
}

data class City(val name: String, val lat: Double, val lon: Double)

object NoaPrefs {
    const val FILE = "noa_prefs"
    const val KEY_SENSITIVITY = "sensitivity"
    const val KEY_PARTICLES = "particles"
    const val KEY_TRANSPARENT_MODE = "transparent_mode"
    const val KEY_TRANSPARENCY = "transparency"
    const val KEY_BLUR = "blur"
    const val KEY_ACCENT = "accent"
    const val KEY_WP_MODE = "wp_mode"          // "cyber" | "image"
    const val KEY_WP_VERSION = "wp_version"    // Long (muda quando troca o wallpaper)
    const val KEY_CITY = "city"
    const val KEY_LAT = "lat"
    const val KEY_LON = "lon"
    const val KEY_PINNED = "pinned"
    const val KEY_COLUMNS = "columns"
    const val KEY_LITE = "lite"
    const val KEY_HIDDEN = "hidden"
    const val KEY_PIN = "pin"
    const val DEFAULT_PIN = "1232"
    const val MAX_PINNED = 8

    val ACCENTS = intArrayOf(
        0xFF00F0FF.toInt(), 0xFFFF2BD6.toInt(), 0xFF39FF14.toInt(),
        0xFFFFB800.toInt(), 0xFFFFFFFF.toInt(), 0xFFB026FF.toInt()
    )
    val ACCENT_NAMES = listOf("CIANO", "MAGENTA", "VERDE", "ÂMBAR", "BRANCO", "ROXO")

    fun get(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun sensitivity(ctx: Context) = get(ctx).getFloat(KEY_SENSITIVITY, 0.5f)
    fun particles(ctx: Context) = get(ctx).getBoolean(KEY_PARTICLES, true)

    fun readUi(ctx: Context): UiPrefs {
        val p = get(ctx); val d = UiPrefs()
        return UiPrefs(
            transparentMode = p.getBoolean(KEY_TRANSPARENT_MODE, d.transparentMode),
            transparency = p.getFloat(KEY_TRANSPARENCY, d.transparency),
            blur = p.getFloat(KEY_BLUR, d.blur),
            accent = p.getInt(KEY_ACCENT, d.accent),
            columns = p.getInt(KEY_COLUMNS, d.columns).coerceIn(4, 6),
            lite = p.getBoolean(KEY_LITE, d.lite)
        )
    }

    fun hidden(ctx: Context): List<String> =
        (get(ctx).getString(KEY_HIDDEN, "") ?: "").split("|").filter { it.isNotBlank() }

    fun setHidden(ctx: Context, list: List<String>) {
        get(ctx).edit().putString(KEY_HIDDEN, list.joinToString("|")).apply()
    }

    fun pin(ctx: Context): String = get(ctx).getString(KEY_PIN, DEFAULT_PIN) ?: DEFAULT_PIN
    fun setPin(ctx: Context, v: String) { get(ctx).edit().putString(KEY_PIN, v).apply() }

    fun pinned(ctx: Context): List<String> =
        (get(ctx).getString(KEY_PINNED, "") ?: "").split("|").filter { it.isNotBlank() }

    fun setPinned(ctx: Context, list: List<String>) {
        get(ctx).edit().putString(KEY_PINNED, list.joinToString("|")).apply()
    }

    fun readCity(ctx: Context): City {
        val p = get(ctx)
        return City(
            name = p.getString(KEY_CITY, "São Paulo") ?: "São Paulo",
            lat = p.getString(KEY_LAT, "-23.5505")?.toDoubleOrNull() ?: -23.5505,
            lon = p.getString(KEY_LON, "-46.6333")?.toDoubleOrNull() ?: -46.6333
        )
    }

    fun setCity(ctx: Context, c: City) {
        get(ctx).edit()
            .putString(KEY_CITY, c.name)
            .putString(KEY_LAT, c.lat.toString())
            .putString(KEY_LON, c.lon.toString())
            .apply()
    }

    /** Emite um novo valor sempre que qualquer preferência mudar (a Home reage ao vivo). */
    fun <T> observe(ctx: Context, read: (Context) -> T): Flow<T> = callbackFlow<T> {
        val prefs = get(ctx)
        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> trySend(read(ctx)) }
        prefs.registerOnSharedPreferenceChangeListener(listener)
        trySend(read(ctx))
        awaitClose { prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }.distinctUntilChanged()
}
