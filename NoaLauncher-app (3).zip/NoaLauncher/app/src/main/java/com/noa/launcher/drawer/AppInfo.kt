package com.noa.launcher.drawer

import android.content.ComponentName
import androidx.compose.ui.graphics.ImageBitmap

data class AppInfo(
    val label: String,
    val component: ComponentName,
    val icon: ImageBitmap
) {
    /** Calculada uma única vez (antes era recriada a cada item/recomposição). */
    val key: String = component.flattenToString()
}
