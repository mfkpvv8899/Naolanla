package com.noa.launcher.home

import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.noa.launcher.settings.SettingsActivity
import com.noa.launcher.settings.UiPrefs

class HomeActivity : ComponentActivity() {

    private val vm: HomeViewModel by viewModels()
    private var blurAnimator: ValueAnimator? = null
    private var currentBlur = 0
    private var windowSolid = false

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { vm.closeDrawer() }
        })

        setContent {
            val open by vm.drawerOpen.collectAsState()
            val ui by vm.ui.collectAsState()

            LaunchedEffect(open, ui.transparentMode, ui.lite, ui.blurRadiusPx) { applyDrawerWindow(open, ui) }

            HomeScreen(
                vm = vm,
                onSwipeDown = ::expandNotifications,
                onSettings = { startActivity(Intent(this, SettingsActivity::class.java)) },
                onGrantMedia = {
                    try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { }
                },
                onHaptic = { window.decorView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
            )
        }
    }

    override fun onStart() {
        super.onStart()
        vm.media.start()
        vm.refreshSys()
    }

    override fun onStop() {
        vm.media.stop()
        super.onStop()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.action == Intent.ACTION_MAIN) vm.closeDrawer()
    }

    /**
     * Drawer aberto e "tudo transparente" desligado -> janela OPACA e sem wallpaper atrás.
     * Isso faz o live wallpaper parar de desenhar e some a mistura de transparência com o wallpaper
     * (principal causa de travada ao rolar/arrastar). Em "tudo transparente" o wallpaper continua atrás
     * (com blur opcional, só fora do modo leve).
     */
    private fun applyDrawerWindow(open: Boolean, ui: UiPrefs) {
        val solid = open && !ui.transparentMode
        if (solid != windowSolid) {
            windowSolid = solid
            if (solid) {
                window.setBackgroundDrawable(ColorDrawable(0xFF030610.toInt()))
                window.clearFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
            } else {
                window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER)
            }
        }
        animateBlur(if (open && ui.transparentMode && !ui.lite) ui.blurRadiusPx else 0)
    }

    private fun animateBlur(target: Int) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return
        if (currentBlur == target) return          // nada a fazer: não mexe na janela
        blurAnimator?.cancel()
        blurAnimator = ValueAnimator.ofInt(currentBlur, target).apply {
            duration = 220
            addUpdateListener {
                currentBlur = it.animatedValue as Int
                window.setBackgroundBlurRadius(currentBlur)
            }
            start()
        }
    }

    /** Requer EXPAND_STATUS_BAR. API oculta via reflection. */
    private fun expandNotifications() {
        try {
            val sb = getSystemService("statusbar")
            Class.forName("android.app.StatusBarManager").getMethod("expandNotificationsPanel").invoke(sb)
        } catch (e: Exception) { }
    }
}
