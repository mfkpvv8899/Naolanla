# Nôa Launcher — edição Cyber

Launcher minimalista/cibernético com wallpaper reativo ao movimento.

## Tela inicial
Relógio · Clima (Open-Meteo, sem chave) · Bateria/Armazenamento/Rede · Player de música (Spotify ou qualquer app de mídia)
· Botões de I.A. (ChatGPT, Claude, Gemini, Copilot, Perplexity — abre o app, ou o site se não estiver instalado)
· Atalhos para os apps que você escolher · botão APPS (ou swipe up) para o drawer com blur.

## Configurações (long press na tela inicial ou botão ⚙)
- Botão ✕ / FECHAR sempre visível
- Aparência: tudo transparente (nível), blur, cor de destaque (ciano/magenta/verde/âmbar)
- Wallpaper: escolher imagem da galeria, restaurar cibernético, sensibilidade, partículas
- Clima: buscar cidade
- Atalhos: escolher até 8 apps (ou segurar um app no drawer para fixar)
- Música: ativar "Acesso a notificações" para mostrar nome/capa da faixa
  (play/pause/próxima/anterior funcionam mesmo sem isso)

## Desempenho
- Wallpaper: fundo pré-renderizado, ~30 fps, canvas por hardware, sensor só com tela visível,
  não redesenha quando nada muda.
- Lista de apps carregada uma vez (atualiza só quando instala/desinstala).
- Blur do drawer animado fora da composição.

## Build
Android Studio (JDK 17) ou GitHub Actions (veja o workflow no repositório).
